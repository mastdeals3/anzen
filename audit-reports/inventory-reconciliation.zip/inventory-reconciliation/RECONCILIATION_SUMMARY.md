# SAPJ Inventory Batch Reconciliation

Generated: 2026-08-01T05:17:19.100Z

Mode: **read only**. No historical stock, movements, reservations, or source
documents were modified.

## Result

| Classification | Batches |
|---|---:|
| Reconciled | 16 |
| Mathematically provable mismatch | 0 |
| Manual review required | 22 |
| **Total batches** | **38** |

## Rules applied

- Batch Creation is the only inbound stock source.
- Approved Delivery Challan is the only normal outbound stock source.
- Sales Invoice physical movement is excluded and must equal zero.
- Active, unreleased reservations determine Reserved Quantity.
- Approved/restocked Material Returns and approved Credit Notes are return
  candidates. Where their relationship cannot be proven, the batch is sent to
  manual review.
- Signed adjustments are accepted only when their direction is mathematically
  supported by their sign or stock-before/stock-after values.
- Positive adjustments without reliable before/after evidence are ambiguous
  because the current adjustment RPC can lose an outbound sign.
- No repair is proposed for a Manual Review batch.

## Repair gate

Only rows classified as `PROVABLE_MISMATCH` are eligible for a later repair
plan. This report does not perform or authorize repair. Every
`MANUAL_REVIEW` row requires documentary investigation first.
