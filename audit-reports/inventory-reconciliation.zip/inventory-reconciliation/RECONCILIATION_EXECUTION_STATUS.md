# Inventory Reconciliation Execution Status

Date: 1 August 2026

Status: **Completed using authenticated read access**

The repository `.env` contains only a Supabase anonymous key. The initial
read-only preflight against:

- `batches`
- `inventory_transactions`
- `stock_reservations`

returned zero visible rows under Row Level Security. The linked Supabase CLI
session was then used to pass the service-role credential directly to the
read-only runner without writing the credential to disk.

The read-only reconciliation runner is available at:

`scripts/inventory-stock-reconciliation.mjs`

For repeat execution it requires:

```text
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
```

The runner performs only `SELECT` requests. It contains no update, insert,
delete, RPC mutation, repair flag, or automatic correction path.

The completed execution generated:

- `batch-reconciliation.csv` — every batch and every requested quantity;
- `manual-review.csv` — ambiguous historical records;
- `provable-mismatches.csv` — mismatches supported by complete mathematical
  evidence;
- `batch-reconciliation.json` — detailed machine-readable evidence;
- `RECONCILIATION_SUMMARY.md` — counts and repair gate.

## Execution result

| Classification | Batches |
|---|---:|
| Reconciled | 16 |
| Mathematically provable mismatch | 0 |
| Manual review required | 22 |
| **Total batches** | **38** |

No historical stock has been repaired or modified. Because there are zero
mathematically provable mismatches, this report currently authorizes no
automatic repair.
